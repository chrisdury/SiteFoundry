
/* Window Openers */
function openWin(url,w,h,c) {
	l=screen.width/2-w/2;
	t=screen.height/2-h/2;
	if (typeof myWindow == "object") {
		myWindow.close();	
	}
	myWindow = window.open(url + '?' + c,'contentadminwindow','top='+t+',left='+l+',height='+h+',width='+w+',noresize,scrollbars=,status=yes');
}
function deleteWarning(item) {
	return confirm('Are you sure you want to delete ' + item + '\n\nThis operation is permanent and there is no undo.  Please be sure before clicking "yes". \n');
}


var updateParent = true;


function closeEditWindow() {
	if (window.opener.document.forms[0].length > 1)
		window.opener.document.forms[0].submit();
	else
		window.opener.document.location.href = window.opener.document.location.href;
		
	window.close();
}



/* Image & Document Library */

var activeTile = null;
var activeLink = null;
function setActiveTile(item) {
	if (activeTile != null)
		activeTile.className = 'imgTile normal';
	
	
	activeTile = item;
	activeTile.className = 'imgTile selected';		
}


function setActiveLink(item) {
	if (activeLink != null)
		activeLink.className = 'normal';
	
	activeLink = item;
	activeLink.className = 'selected';

}

var myWindow;
function openWindow(url,w,h) {
	l=screen.width/2-w/2;
	t=screen.height/2-h/2;
	if (typeof myWindow == "object") {
		myWindow.close();	
	}
	myWindow = window.open(url,'contentadminwindow','top='+t+',left='+l+',height='+h+',width='+w+',noresize,scrollbars=yes,status=yes');
}

/*
function addNode() {
	url = 'helpers/nodeEdit.aspx?action=add';
	openWindow(url,350,300);
}
*/

function editNode(id) {
	url = 'helpers/nodeEdit.aspx?action=edit&id='+id;
	openWindow(url,350,300);
}

function deleteNode(id) {
	url = 'helpers/nodeEdit.aspx?action=delete&id='+id;
	openWindow(url,350,300);
}
