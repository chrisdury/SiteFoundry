using System;

namespace Dury.SiteFoundry
{
	public class Users 
	{
		private static readonly Users instance=new Users();
		public static Users GetInstance() { return instance; }
		static Users() {}
		Users()
		{
		}





	}
}
