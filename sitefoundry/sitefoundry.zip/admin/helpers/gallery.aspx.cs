using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Dury.SiteFoundry;


namespace Dury.SiteFoundry.Admin.helpers
{
	/// <summary>
	/// Summary description for gallery.
	/// </summary>
	public class imageGallery : System.Web.UI.Page
	{

		protected System.Web.UI.WebControls.Repeater imageRepeater;
		public string baseDirectory = SFGlobal.BaseDirectory;
		public string fileDirectory = SFGlobal.SiteRoot + SFGlobal.ResourceFileLocation;
		public string fileDirectoryRelative = SFGlobal.VirtualDirectory  + SFGlobal.ResourceFileLocation;

		private void Page_Load(object sender, System.EventArgs e)
		{
			string[] fileTypes = new string[] { "*.jpg","*.jpeg","*.gif" };
			System.Collections.ArrayList imageFiles = new ArrayList();
			foreach(string ext in fileTypes)
			{
				imageFiles.AddRange(System.IO.Directory.GetFiles(Server.MapPath(fileDirectory),ext));                
			}
			DataTable dt = new DataTable("files");
			dt.Columns.Add("filename",typeof(string));
			dt.Columns.Add("size",typeof(int));
			dt.Columns.Add("height",typeof(int));
			dt.Columns.Add("width",typeof(int));
			dt.Columns.Add("dateModified",typeof(System.DateTime));

			for(int i=0; i<imageFiles.Count; i++) 
			{
				System.IO.FileInfo fi = new System.IO.FileInfo((string)imageFiles[i]);
				System.Drawing.Bitmap b = new Bitmap((string)imageFiles[i]);
				dt.Rows.Add(new object[] { fi.Name,(int)fi.Length,b.Height,b.Width,fi.LastWriteTime });
				b.Dispose();
			}
			dt.DefaultView.Sort = "filename";
			imageRepeater.DataSource = dt.DefaultView;
			imageRepeater.DataBind();
		}



		public string getFileSize(int fs)
		{
			//return fs.ToString("N0");
			float f = (float)fs / (float)1024;
            return f.ToString("N2");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
