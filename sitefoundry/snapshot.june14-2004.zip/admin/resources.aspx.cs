using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using HolmesAndLee.SiteFoundry;
using HolmesAndLee.SiteFoundry.Security;

namespace HolmesAndLee.SiteFoundry.Admin
{
	/// <summary>
	/// Summary description for resources.
	/// </summary>
	public class resources :  HolmesAndLee.UI.BasePage
	{
		private string searchPattern = "*.*";
		private string fileDirectory;
		public string absoluteUrl = string.Empty;
		public string relativeUrl = string.Empty;

		protected System.Web.UI.WebControls.DataGrid filesgrid;
		protected System.Web.UI.WebControls.DropDownList fileFilter;
		protected System.Web.UI.WebControls.Label msg;
		protected System.Web.UI.HtmlControls.HtmlInputFile fileToUpload;
		protected System.Web.UI.WebControls.Button upload;

		protected UserPrincipal user;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.PageTitle = "File Upload";
			this.fileDirectory = SFGlobal.BaseDirectory + SFGlobal.ResourceFileLocation;
			this.absoluteUrl = System.Configuration.ConfigurationSettings.AppSettings["/"];
			this.relativeUrl = "/" + System.Configuration.ConfigurationSettings.AppSettings["virtualDirName"] + SFGlobal.ResourceFileLocation;

			user = (UserPrincipal)Context.User;
	
			if (!IsPostBack) 
			{
				initFileTypes();
				ViewState["sortby"] = null;
				ViewState["sortDirection"] = null;
				getFiles();
				msg.Text = "";

			}
		}
		private void initFileTypes() 
		{
			System.Collections.ArrayList fileTypes = new System.Collections.ArrayList();
			fileTypes.Add("ALL");
			string[] files = System.IO.Directory.GetFiles(fileDirectory,searchPattern);
			for(int i=0; i<files.Length; i++) 
			{
				System.IO.FileInfo fi = new System.IO.FileInfo(files[i]);
				if (!fileTypes.Contains(fi.Extension))
					fileTypes.Add(fi.Extension);
			}
			
			fileFilter.DataSource = fileTypes;
			fileFilter.DataBind();
		}

		public void fileFilter_changed(object sender, System.EventArgs e)
		{
			getFiles();
		}

		private void setSearchPattern()
		{
			switch(fileFilter.SelectedItem.Text) 
			{
				case "ALL":
					searchPattern = "*.*";
					break;
				default:
					searchPattern = "*" + fileFilter.SelectedItem.Text;
					break;
			}
		}

		private void getFiles() 
		{
			setSearchPattern();
			string[] files = System.IO.Directory.GetFiles(fileDirectory,searchPattern);
			DataTable dt = new DataTable("files");
			dt.Columns.Add("filename",typeof(string));
			dt.Columns.Add("size",typeof(long));
			dt.Columns.Add("dateModified",typeof(System.DateTime));

			for(int i=0; i<files.Length; i++) 
			{
				System.IO.FileInfo fi = new System.IO.FileInfo(files[i]);
				dt.Rows.Add(new object[] { fi.Name,fi.Length,fi.LastWriteTime });
				
			}           

			filesgrid.DataSource = dt;
			filesgrid.DataBind();


		}

		public string getKiloBytes(long filesize) 
		{
			//float kb = filesize/1024;
			return filesize.ToString("N0");
		}

		public string getRelativeUrl(string file)
		{
			return relativeUrl + "/" + file;
		}

		public string getAbsoluteUrl(string file)
		{
			return absoluteUrl + "/" + file;
		}


		public void changePage(Object sender, DataGridPageChangedEventArgs e)
		{
			filesgrid.CurrentPageIndex = e.NewPageIndex;
			getFiles();
		} 

		public void sortGrid(Object sender, DataGridSortCommandEventArgs e)
		{
			if (ViewState["sortby"] != null) 
			{
				
				if ((string)ViewState["sortby"] == (string)e.SortExpression)
				{
					ViewState["sortDirection"] = ((string)ViewState["sortDirection"] == "ASC") ? "DESC" : "ASC";
				
				} 
				else 
				{
					ViewState["sortDirection"] = "ASC";
					ViewState["sortby"] = (string)e.SortExpression;
				}
			} 
			else 
			{
				ViewState["sortDirection"] = "ASC";
				ViewState["sortby"] = (string)e.SortExpression;
			}
			getFiles();
		} 

		protected void filesgrid_Delete(System.Object sender, DataGridCommandEventArgs e ) 
		{
			string file = fileDirectory + "/" + e.Item.Cells[0].Text;
			System.IO.File.Delete(file);
			msg.Text = e.Item.Cells[0].Text + " deleted successfully";
			getFiles();


		}

		protected void upload_click(object sender, System.EventArgs e)
		{
			for (int i=0; i<Request.Files.Count; i++)
			{
				if (Request.Files[i].ContentLength > 0)
				{
					string newFile = fileDirectory + "\\" + System.IO.Path.GetFileName(Request.Files[i].FileName);
					Request.Files[i].SaveAs(newFile);
					msg.Text += System.IO.Path.GetFileName(Request.Files[i].FileName) + " uploaded successfully<BR>";
				}
			}
			getFiles();
		}


		protected void filesGrid_OnItemDataBound(object sender, DataGridItemEventArgs e)
		{
			if (e.Item.FindControl("previewHolder") != null && e.Item.Cells[0].Text != null)
			{
				string fn = e.Item.Cells[0].Text;
				string ex = System.IO.Path.GetExtension(fn).ToLower();
				PlaceHolder p = (PlaceHolder)e.Item.FindControl("previewHolder");
				HtmlImage i = new HtmlImage();

				switch (ex)
				{
					case ".jpeg":
					case ".jpg":
					case ".gif":
						i.Src = this.relativeUrl + "/" + e.Item.Cells[0].Text;
						i.Width = 50;
						i.Border = 0;
						p.Controls.Add(i);
						break;


					case ".zip":
						p.Controls.Add(new LiteralControl("ZIP"));
						break;

					case ".pdf":
						i.Src = "~/images/icon-pdf.gif";
						p.Controls.Add(i);
						break;

					case ".doc":
						i.Src = "~/images/icon-doc.gif";
						p.Controls.Add(i);
						break;
				}
			}

				if(e.Item.FindControl("delete") != null)
				{

					if (user.IsInRole(SFGlobal.AdminstratorRoleName) || user.IsInRole(SFGlobal.PublisherRoleName))
					{
						((LinkButton) e.Item.FindControl("delete")).Attributes.Add("onClick", "return deleteWarning('this file?');");
					} 
					else 
					{
						((LinkButton) e.Item.FindControl("delete")).Attributes.Add("onClick", "alert('You do not have permission to delete');return false;");
						((LinkButton)e.Item.FindControl("delete")).Enabled = false;
					}
					

				}
			}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}

