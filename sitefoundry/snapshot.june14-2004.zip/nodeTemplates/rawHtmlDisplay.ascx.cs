namespace HolmesAndLee.SiteFoundry.nodeTemplates
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	using HolmesAndLee.SiteFoundry;
	using HolmesAndLee.SiteFoundry.Security;

	/// <summary>
	///		Summary description for rawHtmlDisplay.
	/// </summary>
	public class rawHtmlDisplay : HolmesAndLee.SiteFoundry.UI.BaseControl
	{
		private Node currentNode;
		protected System.Web.UI.WebControls.Literal body;
		private HolmesAndLee.Data.DAL dal = new HolmesAndLee.Data.DAL();

		private string publicSuffix = "_public";

		private void Page_Load(object sender, System.EventArgs e)
		{
			currentNode = (Node)Context.Items["currentNode"];
            if (currentNode == null) throw new HolmesAndLee.ErrorHandler("currentNode not found!");

			if (SFGlobal.IsUserCMS())
				publicSuffix = "";


			DataSet ds = dal.execDataSet("SELECT showTemplate,title,body FROM SimpleArticles " + publicSuffix + " WHERE nodeID = " + currentNode.Id);
			if (ds.Tables[0].Rows.Count > 0)
			{
				DataRow dr = ds.Tables[0].Rows[0];
				Page.ShowTemplate = (dr["showTemplate"] != System.DBNull.Value) ? (bool)dr["showTemplate"] : false;
				Page.PageTitle = dr["title"].ToString();
				body.Text = dr["body"].ToString();
			}
			else
			{
				body.Text = "content not found in database... too bad... so sad...";

			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
