using System;
using System.Collections;
using System.Data;

namespace HolmesAndLee.SiteFoundry
{
	/// <summary>
	/// Base organizational object for SiteFoundry.  Includes hierarchy organization, multilingual labels, child collections, html and xml output
	/// </summary>
	public class Node
	{

		#region properties

		private int id;
		private int parentID;
		private string filename;
		private IList names;
		private int typeID;
		private bool publish;
		private bool visible;
		private int rank;
		private DateTime dateCreated;
		private DateTime dateModified;
		private IList roles;

		public int Id
		{
			get { return this.id; }
		}

		public int ParentID
		{
			get { return this.parentID; }
			set { this.parentID = value; }
		}

		public string Filename
		{
			get { return this.filename; }
			set { this.filename = value; }
		}

		public int TypeID
		{
			get { return this.typeID; }
			set { this.typeID = value; }
		}

		public bool Publish
		{
			get { return this.publish; }
			set { this.publish = value; }
		}

		
		public bool Visible
		{
			get { return this.visible; }
			set { this.visible = value; }
		}

		public int Rank 
		{
			get { return this.rank; }
			set { this.rank = value; }
		}
		

			public DateTime DateCreated
		{
			get { return this.dateCreated; }
			set { this.dateCreated = value; }
		}

		public DateTime DateModified
		{
			get { return this.dateModified; }
			set { this.dateModified = value; }
		}

		public string URL
		{
			get 
			{
				Node current = this.parent;
				string output = this.filename;
				while (current != null && current.parent != null) 
				{
					output = current.filename + '/' + output;
					current = current.parent;
				}
				output = "/" + SFGlobal.VirtualDirectory + output;
				output += SFGlobal.VirutalFileExtention;
				return output;
			}
		}

		public System.Collections.IList Names
		{
			get { return names; }
		}

		/*
		public System.Collections.IList Roles
		{
			get { return roles; }
		}
		*/


		public Node parent;
		public NodeCollection children;// = new NodeCollection();

		#endregion

		#region constructors

		public Node()
		{
		}

		public Node(int newid)
		{
			this.id = newid;
		}

		public Node(Node newparent)
		{
			this.parent = newparent;
			if (this.parent != null)
				this.parentID = this.parent.id;
			else
				this.parentID = 0;
		}


		public Node(Node newparent,string newfilename,int newTypeID)
		{
			this.parent = newparent;
			if (this.parent != null)
				this.parentID = this.parent.id;
			else
				this.parentID = 0;
			this.filename = newfilename;
			this.typeID = newTypeID;
		}


		#endregion

		#region methods









		private int checkRole(string role)
		{
			int i = -1;
			foreach(NodeRole nr in this.roles)
			{
				if (nr.Name == role)
				{
					//System.Web.HttpContext.Current.Response.Write(this.filename + "=" + nr.Name);
					i = nr.Level;
					break;
				}
			}
			return i;
		}

		/// <summary>
		/// returns integer representing requested role's permission for the current node.  if permission
		/// isn't found locally, then looks up to the parent to find a role entry matching the requested role.
		/// returns 0 (no permissions) if not found.
		/// </summary>
		/// <param name="role">name of role to check</param>
		/// <returns>a number representing the permission (0-31)</returns>
		public int getRolePermission(string role)
		{
			int i = -1;
            //string s = "nodes:";
			Node p = this;
			while(p != null && i == -1)
			{
				i = p.checkRole(role);
				/*
				if (p.roles != null && p.roles.Count > 0)
				{
					s += "[ name=" + p.filename+" count=" + p.roles.Count.ToString();
                    s += " rolePerm=" + i.ToString();
					s += "], <br>";
				}
				*/	
				
				p = p.parent;
			}
			if (i==-1) i=0;
			//System.Web.HttpContext.Current.Response.Write(s);
			return i;
		}


		/// <summary>
		/// Get a iterable list of roles that this node belongs to.
		/// </summary>
		/// <returns></returns>
		public IList GetRoles()
		{
			ArrayList al = new ArrayList();
			Node p = this;
			while(p!= null)
			{
				foreach(NodeRole nr in p.roles)
				{
					al.Add(nr);
				}
				p = p.parent;
			}
			return al;
		}



		/// <summary>
		/// get the node label in the supplied language identifier
		/// </summary>
		/// <param name="key">2(xx) or 5(xx-XX) character localization string.  eg. "en" or "en-CA"</param>
		/// <returns>a string</returns>
		public string getName(string key)
		{
			foreach (NodeName nn in this.names)
			{
				if (nn.Lang == key)
					return nn.Name;
			}
			//throw new Exception("this node doesn't have a node name defined for this language: " + key);
			return "no label defined";
		}


		/// <summary>
		/// Finds and returns a Node, using the supplied ArrayList as a path to the node.
		/// </summary>
		/// <param name="nodeNames">arraylist of nodenames to use as a path to find a node</param>
		/// <returns>a node</returns>
		public Node Find(System.Collections.ArrayList nodeNames)
		{
			if (nodeNames.Count == 0) return this;
			if (nodeNames.Count == 1) if (nodeNames[0].ToString() == this.filename) return this;
			foreach(Node n in this.children)
			{
				if (n.filename == nodeNames[0].ToString())
				{
					nodeNames.RemoveAt(0);
					return n.Find(nodeNames);
				}
			}
			// error message
			string p = string.Empty;
			foreach(string s in nodeNames)
				p += s + ",";
			p = p.Substring(0,p.Length-1);
			throw new HolmesAndLee.ErrorHandler("Can't Find Node: " + p);
		}

		/// <summary>
		/// Finds and returns a Node, using the supplied ID
		/// </summary>
		/// <param name="nodeID">unique indenity of sought node</param>
		/// <returns>node reference from the root</returns>
		public Node Find(int nodeID) 
		{
			if (this.id == nodeID) return this;
			foreach(Node n in this.children)
			{
				Node n1 = n.Find(nodeID);
				if (n1 != null)
					return n1;
			}
			return null;
		}




		public string ToString(int indent)
		{
			string s = "";
			string p = "";
			for(int i=0;i<indent;i++) p+= "-";
			s += p +  this.Filename + "<br>" + System.Environment.NewLine;

			foreach (Node n in this.children)
			{
				s += n.ToString(indent+1);
			}
			return s;
		}

		public string ToPublicXML(string lang)
		{

			string s = "";
			if (this.visible) 
			{
				s += "<menu id=\"" + this.id.ToString() + "\" label=\"" + this.getName(lang) + "\" href=\"" + this.URL + "\" >";
				foreach (Node n in this.children)
				{
					s += n.ToPublicXML(lang);
				}
				s += "</menu>";
			}
			return s;
		}


		public string ToXML()
		{
			string s = "";
			s += "<menu id=\"" + this.id + "\" filename=\"" + this.filename + "\" label=\"" + formatString(this.getName(SFGlobal.DefaultLanguage)) + "\" type=\"" + this.typeID.ToString() + "\" >";
			foreach (Node n in this.children)
			{
				s += n.ToXML();
			}
			s += "</menu>";
			return s;
		}

		private string formatString(string input)
		{
			string[] r = new string[] { "&","&amp;", "'","&apos;", "\"","&quot;", "<","&lt;", ">","&gt;" };
			for(int i=0; i< r.Length; i+=2)
			{
				if (input.IndexOf(r[i]) > 0)
					input = input.Replace(r[i],r[i+1]);
			}
			return input;
		}



		public string ToHTML(int indent)
		{
			string s = "";
			string p = "";
			for(int i=0;i<indent;i++) p+= "&nbsp;&nbsp;&nbsp;";
			s += p +  "<a href=\"" + this.URL + "\">";
			if (System.Web.HttpContext.Current.Request.RawUrl == this.URL) s+= "<b>";
			s +=this.Filename;
			s+= "</a>";
			if (System.Web.HttpContext.Current.Request.RawUrl == this.URL) s+= "</b>";
			s += "<br>" + System.Environment.NewLine;

			foreach (Node n in this.children)
			{
				s += n.ToHTML(indent+1);
			}
			return s;
		}


		public string ToAdminHTML(int indent)
		{
			string s = "";
			string p = "";
			for(int i=0;i<indent;i++) p+= "&nbsp;&nbsp;&nbsp;";
			s += p +  "<a href=\"?nodeID=" + this.id + "\">";
			s +=this.Filename;
			s += "</a>";
			s += "&nbsp;&nbsp;&nbsp;";
			s += "<a href=\"#\" onClick=\"editNode(" + this.id + ");\">edit</a> | <a href=\"#\" onClick=\"deleteNode(" + this.id + ");\">delete</a>";
			s += "<br>" + System.Environment.NewLine;

			foreach (Node n in this.children)
			{
				s += n.ToAdminHTML(indent+1);
			}
			return s;
		}



/*
		public System.Xml.XmlDocument ToXML()
		{
			//<menu id="" label="" expanded="true" />




		}

*/



/*
		public NodeCollection GetChildren()
		{
			if (this.id == 0) return null;
			NodeCollection children = new NodeCollection();
			DataSet ds = this.dal.execDataSet("SELECT * FROM Nodes WHERE parentID = " + this.id);
			if (ds.Tables[0].Rows.Count > 0) 
			{
				for (int i = 0; i < ds.Tables[0].Rows.Count; i++) 
				{
					children.Add(new Node((int)ds.Tables[0].Rows[i]["id"], this));
				}
			}
			return children;
		}
*/



		#endregion

	}

}
