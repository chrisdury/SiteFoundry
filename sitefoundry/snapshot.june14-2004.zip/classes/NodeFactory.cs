using System;
using Wilson.ORMapper;
using HolmesAndLee.Data;


namespace HolmesAndLee.SiteFoundry
{
	/// <summary>
	/// Retrieves nodes from an ObjectManager
	/// </summary>
	public class NodeFactory
	{
		public NodeFactory()
		{
		}


		private static Node getAllNodes(ObjectSpace ObjectManager, int currentNodeID, Node parent)
		{
			Node n = (Node)ObjectManager.GetObject(typeof(Node),currentNodeID);
			n.parent = parent;
			ObjectQuery oq = new ObjectQuery(typeof(Node),"parentID=" + currentNodeID, "rank ASC");
			//ObjectReader or = ObjectManager.GetObjectReader(typeof(Node),"parentID=" + currentNodeID);
			ObjectReader or = ObjectManager.GetObjectReader(oq);
			NodeCollection nc = new NodeCollection();
			foreach (Node childNode in or)
			{
				nc.Add(getAllNodes(ObjectManager,childNode.Id,n));
			}
			n.children = nc;
			return n;           
		}


		public static Node GetAll(ObjectSpace ObjectManager, int startNodeID)
		{
			return getAllNodes(ObjectManager,startNodeID,null);
		}



		/// <summary>
		/// Deletes the supplied Node and all it's children
		/// </summary>
		/// <param name="n">Node you wish to delete</param>
		public static void DeleteNode(Node currentNode)
		{
            SFGlobal.DAL.execNonQuery("DELETE FROM NodeNames WHERE nodeID = " + currentNode.Id);
			foreach(Node n in currentNode.children)
			{
				NodeFactory.DeleteNode(n);
			}
			SFGlobal.ObjectManager.MarkForDeletion(currentNode);
			SFGlobal.ObjectManager.PersistChanges(currentNode);
		}

	}
}
