using System;
using System.Collections;
using System.ComponentModel;
using System.Security.Principal;
using System.Globalization;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml;

using HolmesAndLee.Data;
using HolmesAndLee.SiteFoundry.Security;

namespace HolmesAndLee.SiteFoundry
{
	/// <summary>
	/// Main static class.
	/// All external references in SiteFoundry should pass through here.
	/// Contains references to Data Layer/Object Manager, web.config items and other global information
	/// 
	/// also contains main functions for user authenticiation/authorization, url rewriting, startup and teardown
	/// </summary>
	public class SFGlobal
	{
		private static int startNodeID = 1;
		public static string NodeTemplateLocation;
		public static string ResourceFileLocation;
		public static string BaseDirectory;
		public static string VirtualDirectory;
		public static string VirutalFileExtention;
		public static string SiteRoot;
		public static string DefaultLanguage;
		public static string EncryptionKey;
		public static string EncryptionMethod;
		public static byte[] EncryptionSalt;

		public static string AdminstratorRoleName;
		public static string PublisherRoleName;
		public static string EditorRoleName;
		public static string ContributorRoleName;		

		public static Wilson.ORMapper.ObjectSpace ObjectManager;
		public static Wilson.ORMapper.ObjectSpace ObjectManagerPublic;
		public static DAL DAL;

		public SFGlobal()
		{
            
		}


		/// <summary>
		/// Handles processing of URL replacement and mapping to pages.aspx (page holder)
		/// </summary>
		public static void ProcessRequest() 
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			string r = context.Request.RawUrl;
			if (r.IndexOf("login.aspx") < 0 && r.IndexOf("logout.aspx") < 0 && r.IndexOf("genimage") < 0 && r.IndexOf("asmx") < 0 && r.IndexOf("error.aspx") < 0 && r.IndexOf("insertuser.aspx") < 0) 
			{
				if (r.IndexOf("admin") < 0) HolmesAndLee.SiteFoundry.UrlRewrite.RewritePaths();
				loadUserFromCookie();
				applySecurity();
			} 
			else 
			{
				context.Items.Add("currentNode",null);
			}
			
		}

		public static void SetLangSession()
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			string r = context.Request.RawUrl;
			if (r.IndexOf("?") > 0 && r.IndexOf("=") > 0) 
			{
				string query = r.Substring(r.IndexOf("?"));
				HolmesAndLee.Utils.CustomQueryString cqs = HolmesAndLee.Utils.QueryStringUtils.QueryStringBuilder(query);
				if (cqs["lang"] != null)
				{
					context.Session["lang"] = SFGlobal.SqlCleanString(cqs["lang"]);
				}
			}
			if (context.Session["lang"] == null)
			{
				context.Session["lang"] = SFGlobal.DefaultLanguage;
			}
			CultureInfo culture;
			switch (context.Session["lang"].ToString())
			{
				case "en":
					culture = CultureInfo.CreateSpecificCulture("en-CA");
					break;
				case "fr":
					culture = CultureInfo.CreateSpecificCulture("fr-CA");
					break;
				default:
					culture = CultureInfo.CreateSpecificCulture("en-CA");
					break;
			}
			System.Threading.Thread.CurrentThread.CurrentCulture = culture;
		}



		public static void IncrementUserCount() 
		{
			/*
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			context.Application.Lock();
			int i = (int)context.Application["currentUsers"];
			context.Application["currentUsers"] = i+=1;
			context.Application.UnLock();
			*/
		}

		public static void DecrementUserCount()
		{
			/*
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			context.Application.Lock();
			int i = (int)context.Application["currentUsers"];
			context.Application["currentUsers"] = i-=1;
			context.Application.UnLock();
			*/
		}

		/// <summary>
		/// start up.  get globals, load object mappings, init DAL, etc...
		/// </summary>
		public static void Start()
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;

			// set globals
			NodeTemplateLocation = System.Configuration.ConfigurationSettings.AppSettings["nodeTemplateDirectory"];
			ResourceFileLocation = System.Configuration.ConfigurationSettings.AppSettings["resourceDirectory"];
			VirtualDirectory = System.Configuration.ConfigurationSettings.AppSettings["virtualDirName"];
			SiteRoot = "/" + System.Configuration.ConfigurationSettings.AppSettings["virtualDirName"];
			VirutalFileExtention = System.Configuration.ConfigurationSettings.AppSettings["virtualFileExtension"];
			DefaultLanguage = System.Configuration.ConfigurationSettings.AppSettings["defaultLanguage"];
			BaseDirectory = System.AppDomain.CurrentDomain.BaseDirectory;
			EncryptionKey = System.Configuration.ConfigurationSettings.AppSettings["encryptionKey"];
			EncryptionMethod = System.Configuration.ConfigurationSettings.AppSettings["encryptionMethod"];
			EncryptionSalt = Convert.FromBase64CharArray(EncryptionKey.ToCharArray(),0,EncryptionKey.Length);
			AdminstratorRoleName = System.Configuration.ConfigurationSettings.AppSettings["AdminstratorRoleName"];
			PublisherRoleName = System.Configuration.ConfigurationSettings.AppSettings["PublisherRoleName"];
			EditorRoleName = System.Configuration.ConfigurationSettings.AppSettings["EditorRoleName"];
			ContributorRoleName = System.Configuration.ConfigurationSettings.AppSettings["ContributorRoleName"];

			context.Application.Add("currentUsers",0);

			// start Object-Relational Mappings
			string connection = System.Configuration.ConfigurationSettings.AppSettings["connectionString"];
			string mappings = AppDomain.CurrentDomain.BaseDirectory.Replace("/bin","") + System.Configuration.ConfigurationSettings.AppSettings["objectMappingsFile"];
			ObjectManager = new Wilson.ORMapper.ObjectSpace(mappings,connection,Wilson.ORMapper.Provider.MsSql);
			mappings = AppDomain.CurrentDomain.BaseDirectory.Replace("/bin","") + System.Configuration.ConfigurationSettings.AppSettings["objectMappingsPublicFile"];
			ObjectManagerPublic = new Wilson.ORMapper.ObjectSpace(mappings,connection,Wilson.ORMapper.Provider.MsSql);

			// SQL Data Abstraction Layer
			DAL = new DAL();

			// read templates into memory
			TemplateLoader.Load(System.Configuration.ConfigurationSettings.AppSettings["nodeTemplateDefinitions"]);

			UpdateNodes();
		}

		/// <summary>
		/// updates nodes in memory from datastore
		/// </summary>
		public static void UpdateNodes()
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			context.Application.Lock();

			// check to see if site has been published, then populate application object with public nodes
			string sql = "SELECT id FROM sysobjects WHERE (id = OBJECT_ID(N'[dbo].[Nodes_public]')) AND (OBJECTPROPERTY(id, N'IsUserTable') = 1)";
			object o = SFGlobal.DAL.execScalar(sql);
			if (o != null)
			{
				if (context.Application["nodeRootPublic"] != null)
					context.Application.Add("nodeRootPublic",NodeFactory.GetAll(ObjectManagerPublic, startNodeID));
				else
					context.Application["nodeRootPublic"] = NodeFactory.GetAll(ObjectManagerPublic, startNodeID);
			}

			// read nodes into application object for CMS only
			if (context.Application["nodeRoot"] != null)
				context.Application.Add("nodeRoot",NodeFactory.GetAll(ObjectManager, startNodeID));
			else
				context.Application["nodeRoot"] = NodeFactory.GetAll(ObjectManager, startNodeID);

			context.Application.UnLock();
		}

		/// <summary>
		/// Enforce viewing security
		/// </summary>
		private static void applySecurity()
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			string r = context.Request.RawUrl;
			UserPrincipal up = (UserPrincipal)context.User;
			if (r.IndexOf("admin") < 0) 
			{
				Node currentNode = (Node)context.Items["currentNode"];
				if (!up.CheckRolePermission(currentNode,Permission.View))
				{
					redirectToLogin();
				}
			} 
			else 
			{
				if (up.IsUserCMS())
					return;
				else
					redirectToLogin();
			}
		}


		/// <summary>
		/// See if the current user is a CMS user
		/// </summary>
		/// <returns></returns>
		public static bool IsUserCMS()
		{
			/*
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			UserPrincipal up = (UserPrincipal)context.User;
			return up.IsUserCMS();
			*/
			return CurrentUser().IsUserCMS();
		}

		public static UserPrincipal CurrentUser()
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			return (UserPrincipal)context.User;		
		}


		/// <summary>
		/// Get the UserIdentity from an encrypted cookie
		/// </summary>
		private static void loadUserFromCookie() 
		{
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			string cookieName = FormsAuthentication.FormsCookieName;
			HttpCookie authCookie = context.Request.Cookies[cookieName];

			// add default permissions for unauthenticated (ie. non-cookied) user
			if(null == authCookie) 
			{
				string r = context.Request.RawUrl;
				if (r.IndexOf("admin") < 0)
				{
					ArrayList al = new ArrayList();
					al.Add("Public");
					context.User = CreateUserPrincipal(1,"PublicUser",al);
					return;
				} 
				else
				{
					redirectToLogin();
					return;
				}
					
			}
		

			// now try to load proper permissions
			FormsAuthenticationTicket authTicket = null;
			try
			{
				authTicket = FormsAuthentication.Decrypt(authCookie.Value);
			}
			catch(Exception ex)
			{
				throw new HolmesAndLee.ErrorHandler(ex.Message,ex);
			}

			if (null == authTicket)	redirectToLogin(); 
			// array of items from cookie has the userID as the first element (so we remove it).  all other elements are user roles
			ArrayList groups = new ArrayList(authTicket.UserData.Split(new char[]{'|'}));
			int userID = int.Parse(groups[0].ToString());
			groups.RemoveAt(0);
			context.User = CreateUserPrincipal(userID,authTicket.Name, groups);
		}

		public static UserPrincipal CreateUserPrincipal(int id, string username, ArrayList groups)
		{
			UserIdentity ui = new UserIdentity(id,username);
			UserPrincipal principal = new UserPrincipal(ui, groups); 
			return principal;  
		}

		public static UserPrincipal CreateUserPrincipal(string encryptedString)
		{
			HolmesAndLee.SiteFoundry.Security.Cryptography.SymmetricEncryption se = new HolmesAndLee.SiteFoundry.Security.Cryptography.SymmetricEncryption();
			try
			{
				ArrayList groups = new ArrayList(se.DecryptString(encryptedString,SFGlobal.EncryptionKey).Split('|'));
				int userID = int.Parse((string)groups[0]);
				string username = (string)groups[1];
				groups.RemoveRange(0,2);
				return CreateUserPrincipal(userID,username,groups);
			}
			catch(Exception e)
			{
				throw new HolmesAndLee.ErrorHandler("user decrypt failed",e);
			}
		}



		private static void redirectToLogin()
		{
			string loginPage = System.Configuration.ConfigurationSettings.AppSettings["loginPage"];
			System.Web.HttpContext context = System.Web.HttpContext.Current;
			context.Response.Redirect("~/" + loginPage + "?RequestedUrl=" + context.Server.UrlEncode(context.Request.RawUrl));
		}


		/// <summary>
		/// Loads article template references into memory from XML file.
		/// </summary>
		/// <returns></returns>
		public static System.Collections.Specialized.ListDictionary LoadArticleTemplates()
		{
			string appKeyName = "sf_articleTemplates";
			System.Web.HttpContext context = System.Web.HttpContext.Current;

			if (context.Application[appKeyName] != null)
			{
				return (System.Collections.Specialized.ListDictionary)context.Application[appKeyName];
			}
			else
			{
				System.Collections.Specialized.ListDictionary at = new System.Collections.Specialized.ListDictionary();
				System.Xml.XmlDocument xd = new System.Xml.XmlDocument();
				try
				{
					xd.Load(System.AppDomain.CurrentDomain.BaseDirectory + SFGlobal.NodeTemplateLocation + "\\" + System.Configuration.ConfigurationSettings.AppSettings["articleTemplateDefinitions"]);
					foreach (XmlNode xn in xd["templates"])
					{
						at.Add(int.Parse(xn.Attributes["id"].Value),new ArticleTemplateInfo(xn.Attributes["id"].Value,xn.Attributes["name"].Value,xn.Attributes["src"].Value));
					}
					context.Application.Add(appKeyName,at);
				}
				catch(Exception e)
				{
					throw new HolmesAndLee.ErrorHandler("can't load articleTemplate XML...",e);
				}
				return at;
			}
		}
		public static ArticleTemplateInfo GetArticleTemplate(int id)
		{
			System.Collections.Specialized.ListDictionary at = LoadArticleTemplates();
			if (at[id] == null) throw new HolmesAndLee.ErrorHandler("error loading template... check id or make sure articles are published");
			return (ArticleTemplateInfo)at[id];
		}



		public static string SqlCleanString(string input)
		{
			//string[] restrictedWords = new string[] { "SELECT" , "INSERT", "DELETE", "DROP", "--", ";" };
			string[] restrictedWords = new string[] { "---"};
			foreach(string s in restrictedWords)
			{
				if (input.ToLower().IndexOf(s.ToLower()) > -1)
					throw new HolmesAndLee.ErrorHandler("reserved word(s) or characters used in input text.");
			}
			return input.Replace("'","''");
		}


		public static void DeleteNode(Node n)
		{
			NodeFactory.DeleteNode(n);
		}



	}

	public struct ArticleTemplateInfo
	{
		public string ID;
		public string Name;
		public string Src;
		public ArticleTemplateInfo(string i,string n, string s)
		{
			ID = i;
			Name = n;
			Src = s;
		}


	}
}
