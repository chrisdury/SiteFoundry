using System;

namespace HolmesAndLee.SiteFoundry.UI
{
	/// <summary>
	/// Extended System.Web.UI.Page for our main site template
	/// </summary>
	public class BasePage : System.Web.UI.Page
	{
		private string mainTitle;
		public string MainTitle 
		{
			get { return mainTitle; }
			set { mainTitle = value; }
		}

		private string pageTitle;
		public string PageTitle 
		{
			get { return pageTitle; }
			set { pageTitle = value; }
		}

		public string MetaKeywords = String.Empty;
		public string MetaDescription = String.Empty;
		public DateTime PageTime;
		public bool ShowTemplate = true;
		private string headerFile;
		private string footerFile;

		protected override void OnInit(System.EventArgs e) 
		{
			PageTime = System.DateTime.Now;
			headerFile = (System.Configuration.ConfigurationSettings.AppSettings["siteTemplateHeader"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["siteTemplateHeader"] : "siteTemplates/header.ascx";
			footerFile = (System.Configuration.ConfigurationSettings.AppSettings["siteTemplateFooter"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["siteTemplateFooter"] : "siteTemplates/footer.ascx";
			mainTitle = (System.Configuration.ConfigurationSettings.AppSettings["siteMainTitle"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["siteMainTitle"] : "MainTitle";
			SFGlobal.SetLangSession();
			base.OnInit(e);
		}

		protected override void OnPreRender(EventArgs e)
		{
			if (ShowTemplate) Controls.AddAt(0, LoadControl(headerFile));
			base.OnPreRender (e);
			if (ShowTemplate) Controls.Add(LoadControl(footerFile));
		}

	}






	public class BaseControl : System.Web.UI.UserControl
	{
		public new BasePage Page 
		{
			get { return (BasePage)base.Page; }
		}

	}
}
