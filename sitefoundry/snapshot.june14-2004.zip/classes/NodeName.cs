using System;
using Wilson.ORMapper;

namespace HolmesAndLee.SiteFoundry
{
	/// <summary>
	/// Class to hold node-name information (multi-lingual labels)
	/// This is a class instead of a struct because it must interface with the ObjectManager, which deals with classes
	/// and the effects of using structs are unknown.
	/// </summary>
	public class NodeName
	{
		private int id;
		private string lang;
		private string name;

		public string Lang
		{
			get { return this.lang; }
		}

		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

	}
}
