using System;

namespace HolmesAndLee.SiteFoundry
{
	/// <summary>
	/// Base article object to handle mulitple templates for individual articles
	/// </summary>
	public class BaseArticle : HolmesAndLee.SiteFoundry.UI.BaseControl
	{
		public string ArticleTitle;
		public string ArticleBody;
		public string Summary;
		public string Keywords;
		public DateTime LastModified;

		public BaseArticle()
		{
		}

	}
}
