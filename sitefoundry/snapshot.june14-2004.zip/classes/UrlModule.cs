using System;
using System.Collections;
using System.ComponentModel;
using System.Security.Principal;
using System.Globalization;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml;


namespace HolmesAndLee.SiteFoundry 
{
	/// <summary>
	/// Handles URL Rewriting for SiteFoundry
	/// </summary>
	public class UrlModule : IHttpModule 
	{
        public void Init(System.Web.HttpApplication application) 
		{
			application.BeginRequest += new EventHandler(this.Application_BeginRequest);
		}
        

		// url scheme:  http://mysite.com/en-EN/default.aspx
		//              http://mysite.com/en-EN/whoweare/default.aspx
		//              http://mysite.com/whoweare/gallery.aspx

		private void Application_BeginRequest(object sender, System.EventArgs e) 
		{
			HttpApplication app = ((HttpApplication)(sender));
			HttpContext context = app.Context;

			string r = context.Request.RawUrl;
			string adminDirectory = (System.Configuration.ConfigurationSettings.AppSettings["adminDirectory"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["adminDirectory"] : "admin";
			string virtualDir = (System.Configuration.ConfigurationSettings.AppSettings["virtualDirName"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["virtualDirName"] : "" ;
			string fileExtension = ".html"; //(System.Configuration.ConfigurationSettings.AppSettings["virtualFileExtension"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["virtualFileExtension"] : ".aspx";
			string pageHandler = "test.aspx"; //(System.Configuration.ConfigurationSettings.AppSettings["pageHandler"] != null) ? System.Configuration.ConfigurationSettings.AppSettings["pageHandler"] : "pages.aspx";


			// apply exceptions
			if (r.IndexOf(adminDirectory) < 0)
			{
				string output = "";

				// examine incoming url
				string[] url = r.Substring(1).Replace(virtualDir,"").Split('/');
				System.Collections.Specialized.StringCollection url_parts = new System.Collections.Specialized.StringCollection();
				url_parts.AddRange(url);

				// find language identitfier
				//if (url_parts[0].Length == 5 && url_parts[0].IndexOf("-",2,1) > 0)
				if (url_parts[0].IndexOf("-",2,1) > 0)
				{
					//context.Response.Write("lang identifier found");
					applyLanguage(url_parts[0]);
                    url_parts.RemoveAt(0);
				}


				foreach(string s in url_parts)
				{
					output += s + "*";
				}


				//output = url_parts.Length.ToString();

				// do url rewriting here
				context.RewritePath("~/test.aspx","~/test.aspx",output);

			}

		}


		private void applyLanguage(string lang)
		{

			CultureInfo culture;
			switch (lang)
			{
				case "en":
					culture = CultureInfo.CreateSpecificCulture("en-CA");
					break;
				case "fr":
					culture = CultureInfo.CreateSpecificCulture("fr-CA");
					break;
				default:
					culture = CultureInfo.CreateSpecificCulture(lang);
					break;
			}
			System.Threading.Thread.CurrentThread.CurrentCulture = culture;
		}







        
		public void Dispose() 
		{
		}
	}
}
